#!/system/bin/sh
# X-Sound

# Wait for boot to finish completely
while [[ `getprop sys.boot_completed` -ne 1 ]] && [[ ! -d "/sdcard" ]]
do
       sleep 1
done

# Kernel sound settings adjust
echo "10 10" > /sys/kernel/sound_control/headphone_gain
echo "4" > /sys/kernel/sound_control/mic_gain
echo "4" > /sys/kernel/sound_control/earpiece_gain