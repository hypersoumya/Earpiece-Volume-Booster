#!/system/bin/sh
# X-Sound

ui_print ""
ui_print " --- -Sound Magisk Module ---"
ui_print ""
ui_print "[*] Improving sound quality..."E
ui_print "[*] Boosting Earpiece Sound..."
sleep 2
ui_print ""
ui_print "[*] Fixing volume levels"
sleep 2
ui_print ""
ui_print "[*] Done!"
ui_print ""
sleep 2
ui_print "[*] Reboot is needed"
